// Connect to the server using socket.io
const socket = io();

// Reference to the messages container for academic requests
const academicMessagesContainer = document.getElementById('academicMessages');

// Reference to the academic request form and input elements
const academicRequestForm = document.getElementById('academicRequestForm');
const academicRequestInput = document.getElementById('academicRequestInput');

// Function to add a new message to the academic chat
function addAcademicMessage(message, sender) {
    const div = document.createElement('div');
    div.textContent = message.content;
    div.classList.add('message');
    if (sender === 'self') {
        div.classList.add('sent-message');
    } else {
        div.classList.add('received-message');
    }
    academicMessagesContainer.appendChild(div);
    // Scroll to the bottom to show the latest message
    academicMessagesContainer.scrollTop = academicMessagesContainer.scrollHeight;
}

// Event listener for academic request form submission
academicRequestForm.addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent default form submission
    const messageContent = academicRequestInput.value.trim();
    if (messageContent) {
        const message = {
            content: messageContent,
            sender: 'self' // Set the sender to 'self'
        };
        addAcademicMessage(message, 'self');
        socket.emit('academic_request', message); // Emit the academic message to the server
        academicRequestInput.value = ''; // Clear the input field after sending the message
    }
});

// Event listener for receiving academic messages from the server
socket.on('academic_chat_message', function(message) {
    addAcademicMessage(message, 'other');
});

// Fetch academic messages when the page loads
socket.emit('fetch_messages', 'academic_request');
