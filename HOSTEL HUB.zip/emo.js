const express = require('express');
const bodyParser = require('body-parser');
const nodemailer = require('nodemailer');
const otpGenerator = require('otp-generator');
const path = require('path');
const sqlite3 = require('sqlite3').verbose(); // Import SQLite

const app = express();
const server = require('http').Server(app); // Require 'http' module for Socket.io
const io = require('socket.io')(server); // Initialize Socket.io

const PORT = process.env.PORT || 3000;

app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.static('public'));

const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: '22b01a4542@svecw.edu.in',
        pass: 'SVECW@2022'
    }
});

let storedOTP = '';
let otpTimestamp = 0;

// Open SQLite database connection
const db = new sqlite3.Database('messages.db');

// Create tables if they do not exist
db.serialize(() => {
    db.run('CREATE TABLE IF NOT EXISTS academic_request_messages (id INTEGER PRIMARY KEY AUTOINCREMENT, content TEXT, sender TEXT, timestamp INTEGER)');
    // Add similar code for other types of messages (emergency, necessary things, etc.)
});

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'loginemail.html'));
});

// Handle incorrect email format
app.post('/send-otp', (req, res) => {
    const { email } = req.body;

    if (!email) {
        return res.status(400).sendFile(path.join(__dirname, 'public', 'invalid_email.html'));    
}

    if (!email.includes('b0') || !email.endsWith('@svecw.edu.in')) {
        return res.status(400).sendFile(path.join(__dirname, 'public', 'invalid_email.html'));
    }

    // Generate and send OTP
    const currentTime = Date.now();
    if (currentTime - otpTimestamp < 60000) {
        return res.status(400).send('Error: Please wait before requesting a new OTP');
    }

    storedOTP = otpGenerator.generate(6, { digits: true, alphabets: false, upperCase: false, specialChars: false });
    otpTimestamp = currentTime;

    transporter.sendMail({
        from: '22b01a4542@svecw.edu.in',
        to: email,
        subject: 'OTP for Login',
        text: `Your OTP to login into Hostel Hub is: ${storedOTP}`
    }, (error, info) => {
        if (error) {
            console.log(error);
            res.status(500).send('Error: Unable to send OTP');
        } else {
            console.log('Email sent: ' + info.response);
            res.redirect('/otp.html');
        }
    });
});

// Handle incorrect OTP or expired OTP
app.post('/verify-otp', (req, res) => {
    const { otp } = req.body;

    const currentTime = Date.now();
    if (currentTime - otpTimestamp > 120000) {
        return res.status(400).send('Error: OTP has expired');
    }

    if (otp !== storedOTP) {
        return res.status(401).redirect('/invalid_otp.html');
    }

    // If OTP is correct, redirect to home page
    res.redirect('/home.html');
});

// Socket.io connection for real-time chat
io.on('connection', socket => {
    console.log('A user connected');

    socket.on('academic_request', msg => {
        const timestamp = Date.now();
        const senderEmail = socket.request.session.userEmail; // Get the sender's email from the session
        db.run('INSERT INTO academic_request_messages (content, sender, timestamp) VALUES (?, ?, ?)', [msg.content, senderEmail, timestamp], err => {
            if (err) {
                console.error('Error saving academic request message to database:', err);
                return;
            }
            io.emit('academic_chat_message', msg);
        });
    });

    // Add similar event handlers for other types of messages

    socket.on('disconnect', () => {
        console.log('A user disconnected');
    });
});

server.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
