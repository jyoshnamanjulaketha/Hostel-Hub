// Connect to the server using socket.io
const socket = io();

// Reference to the messages container for necessary things requests
const necessaryMessagesContainer = document.getElementById('necessaryMessages');

// Reference to the necessary things request form and input elements
const necessaryRequestForm = document.getElementById('necessaryRequestForm');
const necessaryRequestInput = document.getElementById('necessaryRequestInput');

// Function to add a new message to the necessary things chat
function addNecessaryMessage(message, sender) {
    const div = document.createElement('div');
    div.textContent = message.content;
    div.classList.add('message');
    if (sender === 'self') {
        div.classList.add('sent-message');
    } else {
        div.classList.add('received-message');
    }
    necessaryMessagesContainer.appendChild(div);
    // Scroll to the bottom to show the latest message
    necessaryMessagesContainer.scrollTop = necessaryMessagesContainer.scrollHeight;
}

// Event listener for necessary things request form submission
necessaryRequestForm.addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent default form submission
    const messageContent = necessaryRequestInput.value.trim();
    if (messageContent) {
        const message = {
            content: messageContent,
            sender: 'self' // Set the sender to 'self'
        };
        addNecessaryMessage(message, 'self');
        socket.emit('necessary_things_request', message); // Emit the necessary things message to the server
        necessaryRequestInput.value = ''; // Clear the input field after sending the message
    }
});

// Event listener for receiving necessary things messages from the server
socket.on('necessary_chat_message', function(message) {
    addNecessaryMessage(message, 'other');
});

// Fetch necessary things messages when the page loads
socket.emit('fetch_messages', 'necessary_things_request');
