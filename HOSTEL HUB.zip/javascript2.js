// Connect to the server using socket.io
const socket = io();

// Reference to the messages container for emergency requests
const emergencyMessagesContainer = document.getElementById('emergencyMessages');

// Reference to the emergency request form and input elements
const emergencyRequestForm = document.getElementById('emergencyRequestForm');
const emergencyRequestInput = document.getElementById('emergencyRequestInput');

// Function to add a new message to the emergency chat
function addEmergencyMessage(message, sender) {
    const div = document.createElement('div');
    div.textContent = message.content;
    div.classList.add('message');
    if (sender === 'self') {
        div.classList.add('sent-message');
    } else {
        div.classList.add('received-message');
    }
    emergencyMessagesContainer.appendChild(div);
    // Scroll to the bottom to show the latest message
    emergencyMessagesContainer.scrollTop = emergencyMessagesContainer.scrollHeight;
}

// Event listener for emergency request form submission
emergencyRequestForm.addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent default form submission
    const messageContent = emergencyRequestInput.value.trim();
    if (messageContent) {
        const message = {
            content: messageContent,
            sender: 'self' // Set the sender to 'self'
        };
        addEmergencyMessage(message, 'self');
        socket.emit('emergency_request', message); // Emit the emergency message to the server
        emergencyRequestInput.value = ''; // Clear the input field after sending the message
    }
});

// Event listener for receiving emergency messages from the server
socket.on('emergency_chat_message', function(message) {
    addEmergencyMessage(message, 'other');
});

// Fetch emergency messages when the page loads
socket.emit('fetch_messages', 'emergency_request');
