// Connect to the server using socket.io
const socket = io();

// Reference to the messages container for food menu messages
const foodMenuMessagesContainer = document.getElementById('foodMenuMessages');

// Reference to the food menu request form and input elements
const foodMenuRequestForm = document.getElementById('foodMenuRequestForm');
const foodMenuRequestInput = document.getElementById('foodMenuRequestInput');

// Function to add a new message to the food menu chat
function addFoodMenuMessage(message, sender) {
    const div = document.createElement('div');
    div.textContent = message.content;
    div.classList.add('message');
    if (sender === 'self') {
        div.classList.add('sent-message');
    } else {
        div.classList.add('received-message');
    }
    foodMenuMessagesContainer.appendChild(div);
    // Scroll to the bottom to show the latest message
    foodMenuMessagesContainer.scrollTop = foodMenuMessagesContainer.scrollHeight;
}

// Event listener for food menu request form submission
foodMenuRequestForm.addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent default form submission
    const messageContent = foodMenuRequestInput.value.trim();
    if (messageContent) {
        const message = {
            content: messageContent,
            sender: 'self' // Set the sender to 'self'
        };
        addFoodMenuMessage(message, 'self');
        socket.emit('food_menu', message); // Emit the food menu message to the server
        foodMenuRequestInput.value = ''; // Clear the input field after sending the message
    }
});

// Event listener for receiving food menu messages from the server
socket.on('food_menu_message', function(message) {
    addFoodMenuMessage(message, 'other');
});

// Fetch food menu messages when the page loads
socket.emit('fetch_messages', 'food_menu');
